1) Download node.js from http://nodejs.org/download/
2) try running the http server using node server.js
3) if it throws any error about mime do npm install mime
4) start the server again as node server.js
5) Access the application through http://localhost:5000/GestureRecognition.html
